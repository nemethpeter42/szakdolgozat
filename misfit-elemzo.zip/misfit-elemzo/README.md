Misfit elemző alkalmazás (BSC Szakdolgozat)
===================

TODO
